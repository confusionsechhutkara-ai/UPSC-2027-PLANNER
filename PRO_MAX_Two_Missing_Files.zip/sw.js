const CACHE='planner-pro-max-211-v1';
self.addEventListener('install',event=>{
  event.waitUntil(
    caches.open(CACHE).then(cache=>
      cache.addAll(['./','./index.html','./manifest.json'])
    )
  );
});
self.addEventListener('fetch',event=>{
  event.respondWith(
    caches.match(event.request).then(response=>response||fetch(event.request))
  );
});
